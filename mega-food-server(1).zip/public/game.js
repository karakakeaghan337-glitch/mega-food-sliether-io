const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const menu=document.getElementById("menu"), play=document.getElementById("play");
const nameBox=document.getElementById("name"), scoreEl=document.getElementById("score");
const statusEl=document.getElementById("status"), board=document.getElementById("board");
let ws,me=null,map={width:5000,height:5000},state={food:[],players:[]},mouse={x:0,y:0},boost=false;

function resize(){canvas.width=innerWidth;canvas.height=innerHeight} addEventListener("resize",resize);resize();
addEventListener("mousemove",e=>{mouse.x=e.clientX;mouse.y=e.clientY});
addEventListener("keydown",e=>{if(e.code==="Space")boost=true});
addEventListener("keyup",e=>{if(e.code==="Space")boost=false});

play.onclick=()=>{
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}`);
  ws.onopen=()=>{ws.send(JSON.stringify({type:"join",name:nameBox.value||"Player"}));menu.classList.add("hidden");statusEl.textContent="Online"};
  ws.onclose=()=>{statusEl.textContent="Disconnected"};
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.type==="welcome"){me=m.id;map=m.map}
    if(m.type==="state"){state=m}
  };
};

function sendInput(){
  if(!ws||ws.readyState!==1)return;
  const cx=canvas.width/2,cy=canvas.height/2;
  ws.send(JSON.stringify({type:"input",angle:Math.atan2(mouse.y-cy,mouse.x-cx),boost}));
}
setInterval(sendInput,50);

function draw(){
  requestAnimationFrame(draw);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const p=state.players.find(x=>x.id===me);
  if(!p)return;
  const scale=Math.min(canvas.width,map.width)/1200;
  const camX=p.x,camY=p.y;

  ctx.save();ctx.translate(canvas.width/2-camX*scale,canvas.height/2-camY*scale);ctx.scale(scale,scale);
  ctx.strokeStyle="#2b2b2b";ctx.lineWidth=2/scale;
  for(let x=0;x<=map.width;x+=100) {ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,map.height);ctx.stroke()}
  for(let y=0;y<=map.height;y+=100) {ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(map.width,y);ctx.stroke()}

  for(const f of state.food){
    ctx.beginPath();ctx.fillStyle=`hsl(${(f.id.length*47)%360} 85% 60%)`;ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fill();
  }
  for(const q of state.players){
    ctx.beginPath();ctx.fillStyle=`hsl(${q.hue} 75% 55%)`;ctx.arc(q.x,q.y,Math.max(12,Math.sqrt(q.length)*2.2),0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.font="14px Arial";ctx.textAlign="center";ctx.fillText(q.name,q.x,q.y-18);
  }
  ctx.restore();
  scoreEl.textContent=`Score: ${p.score}`;
  const top=[...state.players].sort((a,b)=>b.score-a.score).slice(0,8);
  board.innerHTML="<b>Leaderboard</b><br>"+top.map((x,i)=>`${i+1}. ${escapeHtml(x.name)} — ${x.score}`).join("<br>");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
draw();
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = process.env.PORT || 3000;
const MAP = { width: 5000, height: 5000 };
const MAX_FOOD = 2200;
const FOOD_BATCH = 450;
const TICK_MS = 50;

const players = new Map();
const food = new Map();
const server = http.createServer((req, res) => {
  let urlPath = req.url.split("?")[0];
  if (urlPath === "/") urlPath = "/index.html";
  const file = path.join(__dirname, "public", path.normalize(urlPath));
  if (!file.startsWith(path.join(__dirname, "public"))) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const type = {".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8"}[ext] || "application/octet-stream";
    res.writeHead(200, {"Content-Type": type, "Cache-Control":"no-store"});
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });

const rand = (a,b) => Math.random()*(b-a)+a;
const id = () => crypto.randomBytes(5).toString("hex");

function addFood(n) {
  for (let i=0; i<n && food.size<MAX_FOOD; i++) {
    const f = { id:id(), x:rand(50,MAP.width-50), y:rand(50,MAP.height-50), r:rand(4,10), value:Math.floor(rand(1,5)) };
    food.set(f.id,f);
  }
}
addFood(MAX_FOOD);

function makePlayer(name) {
  const p = {
    id:id(), name:String(name||"Player").slice(0,18),
    x:rand(500,MAP.width-500), y:rand(500,MAP.height-500),
    angle:rand(0,Math.PI*2), target:0, speed:3.2,
    boost:false, score:0, length:35,
    hue:Math.floor(rand(0,360)), alive:true
  };
  return p;
}

function broadcast(obj) {
  const msg=JSON.stringify(obj);
  for (const p of players.values()) if (p.ws.readyState===WebSocket.OPEN) p.ws.send(msg);
}

wss.on("connection", ws => {
  const p = makePlayer("Player");
  p.ws=ws;
  players.set(p.id,p);
  ws.send(JSON.stringify({type:"welcome", id:p.id, map:MAP}));
  ws.on("message", raw => {
    try {
      const m=JSON.parse(raw);
      if (m.type==="join") p.name=String(m.name||"Player").slice(0,18);
      if (m.type==="input") {
        if (Number.isFinite(m.angle)) p.target=m.angle;
        p.boost=!!m.boost;
      }
    } catch {}
  });
  ws.on("close",()=>players.delete(p.id));
});

function update() {
  for (const p of players.values()) {
    let d = Math.atan2(Math.sin(p.target-p.angle), Math.cos(p.target-p.angle));
    p.angle += Math.max(-0.12,Math.min(0.12,d));
    const speed = p.speed * (p.boost && p.length>20 ? 1.8 : 1);
    p.x += Math.cos(p.angle)*speed;
    p.y += Math.sin(p.angle)*speed;
    if (p.x<25) p.x=25; if (p.x>MAP.width-25) p.x=MAP.width-25;
    if (p.y<25) p.y=25; if (p.y>MAP.height-25) p.y=MAP.height-25;

    for (const [fid,f] of food) {
      const dx=p.x-f.x, dy=p.y-f.y;
      if (dx*dx+dy*dy < 30*30) {
        food.delete(fid);
        p.score += f.value;
        p.length += f.value;
      }
    }
  }
  if (food.size < MAX_FOOD) addFood(Math.min(FOOD_BATCH, MAX_FOOD-food.size));

  const state = {
    type:"state",
    food:[...food.values()],
    players:[...players.values()].map(p=>({
      id:p.id,name:p.name,x:p.x,y:p.y,angle:p.angle,
      score:p.score,length:p.length,hue:p.hue
    }))
  };
  broadcast(state);
}
setInterval(update,TICK_MS);

server.listen(PORT,()=>console.log(`Mega Food Server running on port ${PORT}`));
# Mega Food Snake Server

This is an **original** browser multiplayer snake game. It is not the official Slither.io server and does not include or modify NTL Mod.

## Run locally

1. Install Node.js.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`.

## GitHub

Upload the entire folder to a GitHub repository. For a Node.js host, use the host's Node/Web Service option and set the start command to:

```text
npm start
```

The server listens on the `PORT` environment variable, which is required by most hosting platforms.

## Mega-food settings

The main settings are at the top of `server.js`:

- `MAX_FOOD = 2200` controls the maximum food count.
- `FOOD_BATCH = 450` controls how quickly food is replenished.
- `MAP.width` and `MAP.height` control the map size.

## NTL Mod note

NTL Mod is a separate third-party client/mod. This project does not bundle, copy, or alter it. Because NTL Mod can change independently, compatibility cannot be guaranteed.